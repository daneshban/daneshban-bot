# Daneshban V2

مرحله اول: هسته ماژولار + آموزش تخصصی ۷ حوزه.

Render:
Build Command: `pip install -r requirements.txt`
Start Command: `python bot.py`

Environment:
`BOT_TOKEN`
