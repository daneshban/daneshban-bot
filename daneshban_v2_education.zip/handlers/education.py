from telegram.constants import ParseMode
from content.education import EDUCATION, LESSONS
from utils.keyboards import education_menu, category_menu, lesson_menu, main_menu

async def education_handler(query):
    text = """<b>📚 آموزش تخصصی دانش‌بان</b>

مسیرهای آموزشی دانش‌بان از مفاهیم پایه تا مباحث کاربردی و آزمونی طراحی می‌شوند.

<b>حوزه موردنظر را انتخاب کن:</b>"""
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=education_menu(EDUCATION))

async def category_handler(query, key):
    data = EDUCATION.get(key)
    if not data:
        await query.edit_message_text("⚠️ حوزه پیدا نشد.", reply_markup=main_menu())
        return
    text = f"""<b>{data[0]}</b>

📚 این مسیر شامل درس‌های مرحله‌بندی‌شده است.
📖 برای شروع، یکی از درس‌ها را انتخاب کن:"""
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=category_menu(key, data))

async def lesson_handler(query, key, lesson_id):
    if key not in EDUCATION or lesson_id not in LESSONS:
        await query.edit_message_text("⚠️ این درس در دسترس نیست.", reply_markup=main_menu())
        return
    await query.edit_message_text(LESSONS[lesson_id], parse_mode=ParseMode.HTML, reply_markup=lesson_menu(key))
