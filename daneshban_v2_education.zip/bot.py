import logging
from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ApplicationBuilder, CallbackQueryHandler, CommandHandler
from config import BOT_TOKEN
from handlers.education import education_handler, category_handler, lesson_handler
from utils.keyboards import main_menu, back_home

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(name)s | %(message)s", level=logging.INFO)
logger = logging.getLogger("daneshban")

WELCOME = """<b>🎓 به دانش‌بان خوش آمدید</b>

<b>دانش را به مهارت تبدیل کن.</b> 🚀

پلتفرم تخصصی یادگیری، تمرین و سنجش مهارت در:
🏦 بانکداری
🌍 تجارت و بازرگانی
📊 مدیریت
💰 اقتصاد و بازار
📈 بازاریابی و فروش
🧑‍🤝‍🧑 مددکاری اجتماعی
🧠 روانشناسی

از منوی زیر شروع کن 👇"""

async def start(update: Update, context):
    await update.effective_message.reply_text(WELCOME, parse_mode=ParseMode.HTML, reply_markup=main_menu())

async def callback(update: Update, context):
    query = update.callback_query
    if not query:
        return
    await query.answer()
    data = query.data or ""

    if data == "home":
        await query.edit_message_text(WELCOME, parse_mode=ParseMode.HTML, reply_markup=main_menu())
    elif data == "education":
        await education_handler(query)
    elif data.startswith("edu:"):
        await category_handler(query, data.split(":", 1)[1])
    elif data.startswith("lesson:"):
        parts = data.split(":")
        if len(parts) == 3:
            await lesson_handler(query, parts[1], parts[2])
        else:
            await query.edit_message_text("⚠️ درخواست نامعتبر است.", reply_markup=back_home())
    elif data in {"exams", "employment", "pdf", "performance", "profile", "support"} or data.startswith(("quiz:", "pdf:")):
        labels = {
            "exams": "🎯 مرکز آزمون",
            "employment": "🏆 آزمون استخدامی",
            "pdf": "📂 جزوات و PDF",
            "performance": "📈 کارنامه من",
            "profile": "👤 پروفایل",
            "support": "🤝 حمایت و پشتیبانی",
        }
        title = labels.get(data, "⏳ این زیرسیستم")
        await query.edit_message_text(
            f"<b>{title}</b>\n\nاین ماژول در مرحله بعد به سیستم واقعی خودش متصل می‌شود.",
            parse_mode=ParseMode.HTML, reply_markup=back_home()
        )
    else:
        await query.edit_message_text("⚠️ گزینه معتبر نیست.", reply_markup=back_home())

async def error_handler(update, context):
    logger.exception("Unhandled exception", exc_info=context.error)

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", start))
    app.add_handler(CallbackQueryHandler(callback))
    app.add_error_handler(error_handler)
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)

if __name__ == "__main__":
    main()
