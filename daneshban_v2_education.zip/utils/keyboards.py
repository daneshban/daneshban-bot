from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def main_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📚 آموزش تخصصی", callback_data="education"), InlineKeyboardButton("🎯 آزمون و تست", callback_data="exams")],
        [InlineKeyboardButton("🏦 بانکداری", callback_data="edu:banking"), InlineKeyboardButton("🌍 تجارت و بازرگانی", callback_data="edu:commerce")],
        [InlineKeyboardButton("📊 مدیریت", callback_data="edu:management"), InlineKeyboardButton("💰 اقتصاد و بازار", callback_data="edu:economy")],
        [InlineKeyboardButton("📈 بازاریابی و فروش", callback_data="edu:marketing"), InlineKeyboardButton("🧑‍🤝‍🧑 مددکاری اجتماعی", callback_data="edu:social_work")],
        [InlineKeyboardButton("🧠 روانشناسی", callback_data="edu:psychology")],
        [InlineKeyboardButton("🏆 آزمون استخدامی", callback_data="employment"), InlineKeyboardButton("📂 جزوات و PDF", callback_data="pdf")],
        [InlineKeyboardButton("📈 کارنامه من", callback_data="performance"), InlineKeyboardButton("👤 پروفایل", callback_data="profile")],
        [InlineKeyboardButton("🤝 حمایت و پشتیبانی", callback_data="support")],
    ])

def back_home():
    return InlineKeyboardMarkup([[InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")]])

def education_menu(education):
    rows = [[InlineKeyboardButton(v[0], callback_data=f"edu:{k}")] for k, v in education.items()]
    rows.append([InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")])
    return InlineKeyboardMarkup(rows)

def category_menu(key, data):
    rows = [[InlineKeyboardButton(f"📖 {x[0]}", callback_data=f"lesson:{key}:{x[1]}")] for x in data[1]]
    rows += [
        [InlineKeyboardButton("🎯 آزمون این حوزه", callback_data=f"quiz:{key}")],
        [InlineKeyboardButton("📂 PDF و جزوات", callback_data=f"pdf:{key}")],
        [InlineKeyboardButton("⬅️ آموزش تخصصی", callback_data="education")],
        [InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")],
    ]
    return InlineKeyboardMarkup(rows)

def lesson_menu(key):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🎯 آزمون این حوزه", callback_data=f"quiz:{key}")],
        [InlineKeyboardButton("⬅️ بازگشت به حوزه", callback_data=f"edu:{key}")],
        [InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")],
    ])
