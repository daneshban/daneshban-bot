from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from content.banking import BANKING, LESSONS, QUIZ

def banking_menu():
    rows = [[InlineKeyboardButton(v["title"], callback_data=f"bankcat:{k}")] for k, v in BANKING.items()]
    rows += [
        [InlineKeyboardButton("🎯 آزمون جامع بانکداری", callback_data="bankquiz:start")],
        [InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")],
    ]
    return InlineKeyboardMarkup(rows)

def category_menu(key):
    data = BANKING[key]
    rows = [[InlineKeyboardButton(f"📖 {title}", callback_data=f"banklesson:{key}:{lid}")]
            for title, lid in data["lessons"]]
    rows += [
        [InlineKeyboardButton("🎯 آزمون این بخش", callback_data=f"bankquiz:category:{key}")],
        [InlineKeyboardButton("⬅️ بانکداری", callback_data="banking")],
        [InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")],
    ]
    return InlineKeyboardMarkup(rows)

async def show_banking(query):
    await query.edit_message_text(
        "<b>🏦 آکادمی بانکداری دانش‌بان</b>\n\nمسیر آموزشی موردنظر را انتخاب کن:",
        parse_mode=ParseMode.HTML,
        reply_markup=banking_menu()
    )

async def show_category(query, key):
    if key not in BANKING:
        await query.edit_message_text("⚠️ بخش بانکی پیدا نشد.", reply_markup=banking_menu())
        return
    await query.edit_message_text(
        f"<b>{BANKING[key]['title']}</b>\n\n📚 یکی از درس‌ها را انتخاب کن:",
        parse_mode=ParseMode.HTML,
        reply_markup=category_menu(key)
    )

async def show_lesson(query, key, lesson_id):
    if key not in BANKING or lesson_id not in LESSONS:
        await query.edit_message_text("⚠️ درس پیدا نشد.", reply_markup=banking_menu())
        return
    await query.edit_message_text(
        LESSONS[lesson_id],
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🎯 آزمون بانکداری", callback_data="bankquiz:start")],
            [InlineKeyboardButton("⬅️ بازگشت", callback_data=f"bankcat:{key}")],
            [InlineKeyboardButton("🏦 بانکداری", callback_data="banking")]
        ])
    )

def questions_for(key=None):
    if key is None:
        return QUIZ
    ids = {lid for _, lid in BANKING[key]["lessons"]}
    return [q for q in QUIZ if q["lesson"] in ids]

async def start_quiz(query, context, key=None):
    questions = questions_for(key)
    if not questions:
        await query.edit_message_text("⚠️ هنوز سؤال این بخش ثبت نشده است.", reply_markup=banking_menu())
        return
    context.user_data["bank_quiz"] = {"questions": questions, "index": 0, "score": 0}
    await send_question(query, context)

async def send_question(query, context):
    state = context.user_data["bank_quiz"]
    q = state["questions"][state["index"]]
    buttons = [[InlineKeyboardButton(o, callback_data=f"bankans:{i}")] for i, o in enumerate(q["options"])]
    buttons.append([InlineKeyboardButton("❌ خروج", callback_data="banking")])
    await query.edit_message_text(
        f"<b>🎯 آزمون بانکداری</b>\n\nسؤال {state['index']+1} از {len(state['questions'])}\n\n<b>{q['question']}</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def answer_quiz(query, context, index):
    state = context.user_data.get("bank_quiz")
    if not state:
        await query.edit_message_text("⚠️ آزمون فعالی وجود ندارد.", reply_markup=banking_menu())
        return
    q = state["questions"][state["index"]]
    correct = int(index) == q["answer"]
    if correct:
        state["score"] += 1

    state["index"] += 1
    if state["index"] >= len(state["questions"]):
        total = len(state["questions"])
        score = state["score"]
        percent = round(score / total * 100)
        context.user_data["bank_last_result"] = {"score": score, "total": total, "percent": percent}
        context.user_data.pop("bank_quiz", None)
        result = "✅ صحیح" if correct else "❌ نادرست"
        await query.edit_message_text(
            f"<b>🏁 پایان آزمون</b>\n\n{result}\n\n"
            f"🏆 امتیاز: {score}/{total}\n📊 درصد: {percent}%\n\n"
            f"<b>💡 توضیح:</b> {q['explanation']}",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎯 آزمون دوباره", callback_data="bankquiz:start")],
                [InlineKeyboardButton("🏦 بانکداری", callback_data="banking")],
                [InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")]
            ])
        )
        return

    await send_question(query, context)
