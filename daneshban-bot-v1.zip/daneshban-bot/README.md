# 🎓 Daneshban Bot

ربات آموزشی حرفه‌ای «دانش‌بان | آموزش مدیریت و بازار»

## امکانات فعلی
- منوی حرفه‌ای فارسی
- آموزش موضوعی در بانکداری، بازرگانی، مدیریت، اقتصاد و بازاریابی
- آزمون تصادفی ۵ سواله
- زمان پاسخ ۲۰ ثانیه برای هر سوال
- امتیازدهی و درصد
- پاسخ تشریحی کوتاه
- پروفایل کاربر
- کارنامه و تحلیل عملکرد
- آمار پایه مدیر
- SQLite برای ثبت آمار کاربران
- آماده استقرار روی Render

## اجرای محلی
```bash
pip install -r requirements.txt
cp .env.example .env
python bot.py
```

در فایل `.env` مقدارهای `BOT_TOKEN` و `ADMIN_ID` را قرار بده.

## Render
Build Command:
```bash
pip install -r requirements.txt
```

Start Command:
```bash
python bot.py
```

متغیرهای محیطی:
- `BOT_TOKEN`
- `ADMIN_ID`

> توکن ربات را هرگز داخل GitHub قرار نده.
