import logging
import random
import time
from html import escape

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.ext import (
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
)

from config import BOT_TOKEN, ADMIN_ID
from db import (
    complete_quiz,
    get_user,
    get_user_count,
    init_db,
    record_answer,
    upsert_user,
)
from content import QUESTIONS, CATEGORY_INFO


logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("daneshban")

QUIZ_SECONDS = 20


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📚 آموزش تخصصی", callback_data="education"),
            InlineKeyboardButton("🎯 آزمون و تست", callback_data="exams"),
        ],
        [
            InlineKeyboardButton("🏦 بانکداری", callback_data="banking"),
            InlineKeyboardButton("🌍 تجارت و بازرگانی", callback_data="commerce"),
        ],
        [
            InlineKeyboardButton("📊 مدیریت", callback_data="management"),
            InlineKeyboardButton("💰 اقتصاد و بازار", callback_data="economy"),
        ],
        [
            InlineKeyboardButton("📈 بازاریابی و فروش", callback_data="marketing"),
            InlineKeyboardButton("🏆 آزمون استخدامی", callback_data="employment"),
        ],
        [
            InlineKeyboardButton("📂 جزوات و منابع", callback_data="resources"),
            InlineKeyboardButton("📈 کارنامه من", callback_data="performance"),
        ],
        [
            InlineKeyboardButton("👤 پروفایل", callback_data="profile"),
            InlineKeyboardButton("🤝 پشتیبانی", callback_data="support"),
        ],
    ])


def back_home() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")]
    ])


def category_keyboard() -> InlineKeyboardMarkup:
    rows = []
    for key, info in CATEGORY_INFO.items():
        rows.append([InlineKeyboardButton(
            f"{info['emoji']} {info['title']}",
            callback_data=f"quizcat:{key}",
        )])
    rows.append([InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")])
    return InlineKeyboardMarkup(rows)


def education_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏦 بانکداری", callback_data="learn:banking")],
        [InlineKeyboardButton("🌍 تجارت و بازرگانی", callback_data="learn:commerce")],
        [InlineKeyboardButton("📊 مدیریت", callback_data="learn:management")],
        [InlineKeyboardButton("💰 اقتصاد و بازار", callback_data="learn:economy")],
        [InlineKeyboardButton("📈 بازاریابی و فروش", callback_data="learn:marketing")],
        [InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")],
    ])


LEARNING_TEXT = {
    "banking": (
        "🏦 <b>بانکداری</b>\n\n"
        "مفاهیم پایه، سپرده‌ها، تسهیلات، عقود، چک، اعتبارسنجی، "
        "بانکداری الکترونیک، ریسک و مبارزه با پولشویی.\n\n"
        "🎯 هدف: ساخت یک مسیر آموزشی کاربردی برای دانشگاه، بازار کار و آزمون‌های استخدامی."
    ),
    "commerce": (
        "🌍 <b>تجارت و بازرگانی</b>\n\n"
        "مبانی تجارت بین‌الملل، اینکوترمز، حمل‌ونقل، اسناد تجاری، "
        "روش‌های پرداخت و مدیریت زنجیره تأمین.\n\n"
        "🎯 هدف: تبدیل مفاهیم تجاری به مهارت قابل استفاده."
    ),
    "management": (
        "📊 <b>مدیریت</b>\n\n"
        "اصول مدیریت، برنامه‌ریزی، سازماندهی، رهبری، کنترل، تصمیم‌گیری "
        "و تحلیل کسب‌وکار.\n\n"
        "🎯 هدف: تقویت نگاه مدیریتی و حل مسئله."
    ),
    "economy": (
        "💰 <b>اقتصاد و بازار</b>\n\n"
        "تورم، نرخ بهره، ارز، سیاست پولی و مالی، عرضه و تقاضا و تحلیل بازار.\n\n"
        "🎯 هدف: درک بهتر رفتار اقتصاد و بازار."
    ),
    "marketing": (
        "📈 <b>بازاریابی و فروش</b>\n\n"
        "STP، آمیخته بازاریابی، برند، رفتار مشتری، قیف فروش و استراتژی فروش.\n\n"
        "🎯 هدف: تبدیل دانش بازاریابی به تصمیم عملی."
    ),
}


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user or not update.effective_message:
        return

    upsert_user(user.id, user.username, user.first_name)

    text = (
        "🎓 <b>دانش‌بان | آموزش مدیریت و بازار</b>\n\n"
        "<b>مدیریت را یاد بگیر؛ بازار را تحلیل کن.</b> 🚀\n\n"
        "یک دستیار آموزشی تخصصی برای یادگیری، تمرین و سنجش مهارت در "
        "حوزه‌های مدیریت، بانکداری، بازرگانی، اقتصاد و بازاریابی.\n\n"
        "از منوی زیر شروع کن 👇"
    )
    await update.effective_message.reply_text(
        text, parse_mode=ParseMode.HTML, reply_markup=main_menu()
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        "🆘 <b>راهنمای دانش‌بان</b>\n\n"
        "/start — شروع و منوی اصلی\n"
        "/help — راهنما\n\n"
        "در آزمون‌ها پاسخ درست، امتیاز، درصد و تحلیل عملکرد ثبت می‌شود.",
        parse_mode=ParseMode.HTML,
        reply_markup=back_home(),
    )


async def show_profile(query, user_id: int) -> None:
    row = get_user(user_id)
    if not row:
        text = "👤 هنوز اطلاعاتی برای پروفایل ثبت نشده است."
    else:
        total = row["questions_answered"]
        correct = row["correct_answers"]
        percent = (correct / total * 100) if total else 0
        name = escape(row["first_name"] or "کاربر")
        text = (
            f"👤 <b>پروفایل {name}</b>\n\n"
            f"🧠 سوال پاسخ‌داده‌شده: <b>{total}</b>\n"
            f"✅ پاسخ صحیح: <b>{correct}</b>\n"
            f"📊 دقت: <b>{percent:.0f}%</b>\n"
            f"⭐ امتیاز: <b>{row['total_score']}</b>\n"
            f"🏆 آزمون تکمیل‌شده: <b>{row['quizzes_completed']}</b>\n\n"
            "ادامه بده؛ هر پاسخ درست یک قدم به سطح حرفه‌ای نزدیک‌ترت می‌کند. 🚀"
        )
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=back_home())


async def show_performance(query, user_id: int) -> None:
    row = get_user(user_id)
    if not row or row["questions_answered"] == 0:
        text = (
            "📈 <b>کارنامه من</b>\n\n"
            "هنوز داده کافی برای تحلیل نداریم.\n"
            "یک آزمون کوتاه شروع کن تا کارنامه‌ات ساخته شود."
        )
    else:
        total = row["questions_answered"]
        correct = row["correct_answers"]
        percent = correct / total * 100
        if percent >= 85:
            level = "🏆 حرفه‌ای"
        elif percent >= 70:
            level = "🔥 پیشرفته"
        elif percent >= 50:
            level = "📘 متوسط"
        else:
            level = "🌱 در حال یادگیری"

        text = (
            "📈 <b>تحلیل عملکرد</b>\n\n"
            f"سطح فعلی: <b>{level}</b>\n"
            f"تعداد پاسخ‌ها: <b>{total}</b>\n"
            f"پاسخ صحیح: <b>{correct}</b>\n"
            f"درصد موفقیت: <b>{percent:.1f}%</b>\n"
            f"امتیاز کل: <b>{row['total_score']}</b>\n\n"
            "💡 پیشنهاد: موضوعاتی را که درصد پایین‌تری دارند دوباره مطالعه کن و سپس آزمون را تکرار کن."
        )
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=back_home())


async def start_quiz(query, context, category: str) -> None:
    questions = QUESTIONS.get(category, [])
    if not questions:
        await query.edit_message_text("⚠️ سوالی برای این بخش ثبت نشده است.", reply_markup=back_home())
        return

    selected = random.sample(questions, min(5, len(questions)))
    context.user_data["quiz"] = {
        "category": category,
        "questions": selected,
        "index": 0,
        "score": 0,
        "correct": 0,
        "started": time.time(),
    }
    await send_question(query, context)


async def send_question(query, context) -> None:
    quiz = context.user_data.get("quiz")
    if not quiz:
        await query.edit_message_text("⚠️ آزمون پیدا نشد.", reply_markup=back_home())
        return

    index = quiz["index"]
    questions = quiz["questions"]

    if index >= len(questions):
        user_id = query.from_user.id
        complete_quiz(user_id)
        total = len(questions)
        correct = quiz["correct"]
        percent = correct / total * 100 if total else 0
        text = (
            "🏁 <b>آزمون به پایان رسید!</b>\n\n"
            f"📚 موضوع: <b>{CATEGORY_INFO[quiz['category']]['title']}</b>\n"
            f"✅ صحیح: <b>{correct} از {total}</b>\n"
            f"📊 درصد: <b>{percent:.0f}%</b>\n"
            f"⭐ امتیاز این آزمون: <b>{quiz['score']}</b>\n\n"
            "نتیجه در کارنامه‌ات ثبت شد. 🚀"
        )
        context.user_data.pop("quiz", None)
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=back_home())
        return

    q = questions[index]
    buttons = [
        [InlineKeyboardButton(f"{i+1}) {option}", callback_data=f"answer:{index}:{i}")]
        for i, option in enumerate(q["options"])
    ]
    buttons.append([InlineKeyboardButton("⛔ پایان آزمون", callback_data="quiz_cancel")])

    text = (
        f"🎯 <b>سوال {index+1} از {len(questions)}</b>\n"
        f"⏱ زمان پاسخ: <b>{QUIZ_SECONDS} ثانیه</b>\n\n"
        f"{q['question']}"
    )
    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(buttons)
    )

    if context.job_queue:
        name = f"quiz_timeout_{query.from_user.id}"
        for job in context.job_queue.get_jobs_by_name(name):
            job.schedule_removal()
        context.job_queue.run_once(
            quiz_timeout,
            QUIZ_SECONDS,
            chat_id=query.message.chat_id,
            user_id=query.from_user.id,
            name=name,
            data={"index": index},
        )


async def quiz_timeout(context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = context.job.user_id
    if not user_id:
        return
    quiz = context.application.user_data.get(user_id, {}).get("quiz")
    if not quiz:
        return
    if quiz["index"] != context.job.data["index"]:
        return

    quiz["index"] += 1
    await context.bot.send_message(
        chat_id=context.job.chat_id,
        text="⏰ <b>زمان این سوال تمام شد.</b>\n\nبه سوال بعدی می‌رویم.",
        parse_mode=ParseMode.HTML,
    )
    await send_question_from_job(context)


async def send_question_from_job(context) -> None:
    user_id = context.job.user_id
    quiz = context.application.user_data.get(user_id, {}).get("quiz")
    if not quiz:
        return

    if quiz["index"] >= len(quiz["questions"]):
        complete_quiz(user_id)
        total = len(quiz["questions"])
        percent = quiz["correct"] / total * 100 if total else 0
        await context.bot.send_message(
            chat_id=context.job.chat_id,
            text=(
                "🏁 <b>آزمون تمام شد!</b>\n\n"
                f"✅ صحیح: <b>{quiz['correct']} از {total}</b>\n"
                f"📊 درصد: <b>{percent:.0f}%</b>\n"
                f"⭐ امتیاز: <b>{quiz['score']}</b>"
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=back_home(),
        )
        context.application.user_data[user_id].pop("quiz", None)
        return

    q = quiz["questions"][quiz["index"]]
    buttons = [
        [InlineKeyboardButton(f"{i+1}) {option}", callback_data=f"answer:{quiz['index']}:{i}")]
        for i, option in enumerate(q["options"])
    ]
    buttons.append([InlineKeyboardButton("⛔ پایان آزمون", callback_data="quiz_cancel")])
    await context.bot.send_message(
        chat_id=context.job.chat_id,
        text=(
            f"🎯 <b>سوال {quiz['index']+1} از {len(quiz['questions'])}</b>\n"
            f"⏱ زمان پاسخ: <b>{QUIZ_SECONDS} ثانیه</b>\n\n{q['question']}"
        ),
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(buttons),
    )
    if context.job_queue:
        name = f"quiz_timeout_{user_id}"
        context.job_queue.run_once(
            quiz_timeout, QUIZ_SECONDS, chat_id=context.job.chat_id,
            user_id=user_id, name=name, data={"index": quiz["index"]}
        )


async def handle_answer(query, context, index: int, option: int) -> None:
    quiz = context.user_data.get("quiz")
    if not quiz or index != quiz["index"]:
        await query.answer("این سوال دیگر فعال نیست.", show_alert=True)
        return

    q = quiz["questions"][index]
    correct = option == q["answer"]
    gained = 10 if correct else 0
    record_answer(query.from_user.id, correct, gained)

    quiz["score"] += gained
    if correct:
        quiz["correct"] += 1

    for job in context.job_queue.get_jobs_by_name(f"quiz_timeout_{query.from_user.id}") if context.job_queue else []:
        job.schedule_removal()

    result = "✅ <b>پاسخ درست بود!</b>" if correct else "❌ <b>پاسخ نادرست بود.</b>"
    explanation = q.get("explanation", "")
    quiz["index"] += 1

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("➡️ سوال بعدی", callback_data="next_question")]
    ])
    await query.edit_message_text(
        f"{result}\n\n"
        f"💡 <b>نکته:</b> {explanation}\n\n"
        f"⭐ امتیاز فعلی: <b>{quiz['score']}</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=keyboard,
    )


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not query:
        return
    await query.answer()

    data = query.data or ""
    user = query.from_user
    upsert_user(user.id, user.username, user.first_name)

    if data == "home":
        await query.edit_message_text(
            "🎓 <b>دانش‌بان</b>\n\nاز منوی اصلی مسیرت را انتخاب کن 👇",
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu(),
        )
        return

    if data == "education":
        await query.edit_message_text(
            "📚 <b>آموزش تخصصی</b>\n\nیک حوزه را انتخاب کن:",
            parse_mode=ParseMode.HTML,
            reply_markup=education_keyboard(),
        )
        return

    if data.startswith("learn:"):
        category = data.split(":", 1)[1]
        await query.edit_message_text(
            LEARNING_TEXT.get(category, "این درس در حال توسعه است."),
            parse_mode=ParseMode.HTML,
            reply_markup=back_home(),
        )
        return

    if data == "exams":
        await query.edit_message_text(
            "🎯 <b>مرکز آزمون دانش‌بان</b>\n\n"
            "۵ سوال تصادفی، زمان پاسخ ۲۰ ثانیه برای هر سوال و ثبت نتیجه در کارنامه.\n\n"
            "موضوع آزمون را انتخاب کن:",
            parse_mode=ParseMode.HTML,
            reply_markup=category_keyboard(),
        )
        return

    if data.startswith("quizcat:"):
        category = data.split(":", 1)[1]
        await start_quiz(query, context, category)
        return

    if data.startswith("answer:"):
        _, index, option = data.split(":")
        await handle_answer(query, context, int(index), int(option))
        return

    if data == "next_question":
        await send_question(query, context)
        return

    if data == "quiz_cancel":
        context.user_data.pop("quiz", None)
        await query.edit_message_text(
            "⛔ آزمون متوقف شد.\n\nهر زمان آماده بودی دوباره شروع کن.",
            reply_markup=main_menu(),
        )
        return

    if data == "profile":
        await show_profile(query, user.id)
        return

    if data == "performance":
        await show_performance(query, user.id)
        return

    if data == "banking":
        await query.edit_message_text(
            LEARNING_TEXT["banking"], parse_mode=ParseMode.HTML, reply_markup=back_home()
        )
        return
    if data == "commerce":
        await query.edit_message_text(
            LEARNING_TEXT["commerce"], parse_mode=ParseMode.HTML, reply_markup=back_home()
        )
        return
    if data == "management":
        await query.edit_message_text(
            LEARNING_TEXT["management"], parse_mode=ParseMode.HTML, reply_markup=back_home()
        )
        return
    if data == "economy":
        await query.edit_message_text(
            LEARNING_TEXT["economy"], parse_mode=ParseMode.HTML, reply_markup=back_home()
        )
        return
    if data == "marketing":
        await query.edit_message_text(
            LEARNING_TEXT["marketing"], parse_mode=ParseMode.HTML, reply_markup=back_home()
        )
        return

    if data == "employment":
        await query.edit_message_text(
            "🏆 <b>مرکز آزمون استخدامی</b>\n\n"
            "مسیر پیشنهادی برای آمادگی آزمون‌های استخدامی بانک‌ها:\n\n"
            "📘 دروس تخصصی\n"
            "🧠 هوش و استعداد\n"
            "⏱ مدیریت زمان\n"
            "🎯 آزمون‌های شبیه‌سازی‌شده\n"
            "📈 تحلیل عملکرد\n\n"
            "این بخش آماده توسعه با بانک سوالات اختصاصی است.",
            parse_mode=ParseMode.HTML,
            reply_markup=category_keyboard(),
        )
        return

    if data == "resources":
        await query.edit_message_text(
            "📂 <b>جزوات و منابع</b>\n\n"
            "این بخش برای PDF، جزوات، خلاصه‌درس‌ها و منابع تکمیلی طراحی شده است.\n\n"
            "📌 در نسخه بعدی، دسته‌بندی و جست‌وجوی منابع اضافه می‌شود.",
            parse_mode=ParseMode.HTML,
            reply_markup=back_home(),
        )
        return

    if data == "support":
        await query.edit_message_text(
            "🤝 <b>پشتیبانی دانش‌بان</b>\n\n"
            "برای پیشنهاد محتوا، گزارش خطا یا همکاری آموزشی، پیام خودت را برای مدیر ارسال کن.\n\n"
            "📌 شناسه پشتیبانی را می‌توانیم در تنظیمات پروژه قرار دهیم.",
            parse_mode=ParseMode.HTML,
            reply_markup=back_home(),
        )
        return

    if data == "admin_stats":
        if ADMIN_ID and user.id == ADMIN_ID:
            await query.edit_message_text(
                f"👑 <b>آمار مدیریت</b>\n\n👥 کاربران ثبت‌شده: <b>{get_user_count()}</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=back_home(),
            )
        else:
            await query.answer("دسترسی مجاز نیست.", show_alert=True)


async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.effective_user or update.effective_user.id != ADMIN_ID:
        await update.effective_message.reply_text("⛔ دسترسی مجاز نیست.")
        return
    await update.effective_message.reply_text(
        f"👑 کاربران ثبت‌شده: {get_user_count()}"
    )


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.exception("Unhandled error", exc_info=context.error)


def main() -> None:
    init_db()
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("stats", admin_stats))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_error_handler(error_handler)

    logger.info("Daneshban is starting...")
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == "__main__":
    main()
