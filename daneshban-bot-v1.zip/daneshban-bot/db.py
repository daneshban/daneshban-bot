import sqlite3
from pathlib import Path

DB_PATH = Path("daneshban.db")


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                joined_at TEXT DEFAULT CURRENT_TIMESTAMP,
                questions_answered INTEGER DEFAULT 0,
                correct_answers INTEGER DEFAULT 0,
                total_score INTEGER DEFAULT 0,
                quizzes_completed INTEGER DEFAULT 0
            )
            """
        )
        conn.commit()


def upsert_user(user_id, username, first_name) -> None:
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO users(user_id, username, first_name)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username=excluded.username,
                first_name=excluded.first_name
            """,
            (user_id, username, first_name),
        )
        conn.commit()


def record_answer(user_id, correct, score) -> None:
    with connect() as conn:
        conn.execute(
            """
            UPDATE users
            SET questions_answered = questions_answered + 1,
                correct_answers = correct_answers + ?,
                total_score = total_score + ?
            WHERE user_id = ?
            """,
            (1 if correct else 0, score, user_id),
        )
        conn.commit()


def complete_quiz(user_id) -> None:
    with connect() as conn:
        conn.execute(
            "UPDATE users SET quizzes_completed = quizzes_completed + 1 WHERE user_id = ?",
            (user_id,),
        )
        conn.commit()


def get_user(user_id):
    with connect() as conn:
        return conn.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()


def get_user_count() -> int:
    with connect() as conn:
        return int(conn.execute("SELECT COUNT(*) FROM users").fetchone()[0])
