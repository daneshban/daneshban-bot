import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID_RAW = os.getenv("ADMIN_ID", "0").strip()

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is not configured.")

try:
    ADMIN_ID = int(ADMIN_ID_RAW or 0)
except ValueError as exc:
    raise RuntimeError("ADMIN_ID must be a valid integer.") from exc
